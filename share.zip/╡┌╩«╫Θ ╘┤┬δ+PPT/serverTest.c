#include <stdio.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <sys/types.h>
#include <strings.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include "uart.h"

#define ADDR "192.168.7.61"
#define PORT "8888"

unsigned char buf_data[256] = {0}; 	//接收客户端发来的命令

unsigned char send_to_M0(int uart0_fd, int connfd)//向M0发送指令
{
	unsigned char ret = 0;
	uart_send(uart0_fd,buf_data,strlen(buf_data));
	memset(buf_data,0,sizeof(buf_data));
	uart_recv(uart0_fd,buf_data,strlen(buf_data)-1,1);
	
	send(connfd,buf_data,strlen(buf_data),0);
	ret = buf_data[0];
	memset(buf_data,0,sizeof(buf_data));
	
	return ret;//返回数组第一个元素
}

int main(int argc, const char *argv[])
{
	//socket
	int sockfd = socket(AF_INET,SOCK_STREAM,0);
	//IPv4，流式套接字，默认填0 
	if(sockfd == -1)
	{
		perror("socket");
		return -1;
	}

	//ip/port
	struct sockaddr_in saddr;
	bzero(&saddr,sizeof(saddr));//清空结构体
	saddr.sin_family 			= AF_INET;//协议族 IPv4
	saddr.sin_port 				= htons(atoi(PORT));//htons  主机字节序转换成网络字节序
	saddr.sin_addr.s_addr 		= inet_addr(ADDR);//点分十进制转换成网络字节序
    //避免服务器重启的时候报address already in use
    int opt = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));
	//bind
	int ret = bind(sockfd,(const struct sockaddr *)&saddr, sizeof(saddr));
	//套接字，地址结构体，结构体的长度
	if(ret == -1)
	{
		perror("bind");
		return -1;
	}

	//listen
	ret = listen(sockfd,10);//等待队列
	if(ret == -1)
	{
		perror("listen");
        return -1;
	}

	//accept
//	struct sockaddr_in caddr;
//	int connfd = accept(sockfd,(struct sockaddr *)&caddr, sizeof(caddr));
	int connfd = accept(sockfd,NULL,NULL);	//接受连接产生新的套接字
	//获取连接套接字，NULL表示不在意地址
	if(connfd == -1)
	{
		perror("accept");
        return -1;
	}
	
	int uartfd = uart_open("/dev/ttyUSB0");//打开串口
	uart_init(uartfd, 115200,0,8,1,'N');//串口初始化

	
	while(1)							//循环读取发送
	{
		memset(buf_data,0,sizeof(buf_data));//对buf_data进行清空
		//recv  接收数据
		ret = recv(connfd,buf_data,sizeof(buf_data)-1,0);
		//接受套接字， 接收数据缓冲区，接收的最大程度，标志位→默认填零
	//	ret = read(connfd,buf_data,sizeof(buf_data));//同recv
		printf("%s\n",buf_data);//打印接收到的数据
	
		if(ret == -1)
		{
			perror("recv");
			return -1;
		}
		//send
		//ret = send(connfd,buf_data,sizeof(buf_data),0);
		if(buf_data[0] == '1')
		{ 
            send_to_M0(uartfd,connfd);
			memset(buf_data,0,sizeof(buf_data));//对buf_data进行清空
			strcpy(buf_data,"led on");				//对buf_data赋值
			send(connfd,buf_data,sizeof(buf_data),0); //将buf_data发送回去

		}
		else if(buf_data[0] == '2')
		{
			send_to_M0(uartfd,connfd);
			memset(buf_data,0,sizeof(buf_data));//对buf_data进行清空
			strcpy(buf_data,"led off");				//对buf_data赋值
			send(connfd,buf_data,sizeof(buf_data),0); //将buf_data发送回去
		}
		else if(buf_data[0] == '3')
		{
			send_to_M0(uartfd,connfd);
			memset(buf_data,0,sizeof(buf_data));//对buf_data进行清空
			strcpy(buf_data,"led1 on");				//对buf_data赋值
			send(connfd,buf_data,sizeof(buf_data),0); //将buf_data发送回去
		}
		else if(buf_data[0] == '4')
		{
			send_to_M0(uartfd,connfd);
			memset(buf_data,0,sizeof(buf_data));//对buf_data进行清空
			strcpy(buf_data,"led1 off");				//对buf_data赋值
			send(connfd,buf_data,sizeof(buf_data),0); //将buf_data发送回去
		}
		else if(buf_data[0] == '5')
		{
			send_to_M0(uartfd,connfd);
			memset(buf_data,0,sizeof(buf_data));//对buf_data进行清空
			strcpy(buf_data,"buzzer on");				//对buf_data赋值
			send(connfd,buf_data,sizeof(buf_data),0); //将buf_data发送回去
		}
		else if(buf_data[0] == '6')
		{
			send_to_M0(uartfd,connfd);
			memset(buf_data,0,sizeof(buf_data));//对buf_data进行清空
			strcpy(buf_data,"buzzer off");				//对buf_data赋值
			send(connfd,buf_data,sizeof(buf_data),0); //将buf_data发送回去
		}
		else if(buf_data[0] == '7')
		{
			send_to_M0(uartfd,connfd);
            memset(buf_data,0,sizeof(buf_data));
            strcpy(buf_data,"fan on");
            send(connfd,buf_data,sizeof(buf_data),0);
		}
        else if(buf_data[0] == '8')
        {
			send_to_M0(uartfd,connfd);
            memset(buf_data,0,sizeof(buf_data));
            strcpy(buf_data,"fan off");
            send(connfd,buf_data,sizeof(buf_data),0); 
        }
        else if(buf_data[0] == '0')
        {
			send_to_M0(uartfd,connfd);
            memset(buf_data,0,sizeof(buf_data));
            strcpy(buf_data,"all off");
            send(connfd,buf_data,sizeof(buf_data),0); 
        }
        else if(buf_data[0] == 'e')
        {
            char buf_send[36] = {0};
			send_to_M0(uartfd,connfd);
            memset(buf_data,0,sizeof(buf_data));
            strcpy(buf_data,"send env");
            /*sprintf(buf_send,"%d:%d:%d",(buf_data[5]+buf_data[4]/10),(buf_data[7]+buf_data[6]/10),
                            (buf_data[20]+(buf_data[21]<<8)+(buf_data[22]<<16)+(buf_data[23]<<24)));
            printf("data=%s\n",buf_send);*/
            send(connfd,buf_data,sizeof(buf_data),0); 
        }

	}
	
finish:
	//关闭套接字，顺序不能错
	uart_close(uartfd);
	close(connfd);
	close(sockfd);
	
	return 0;
}
