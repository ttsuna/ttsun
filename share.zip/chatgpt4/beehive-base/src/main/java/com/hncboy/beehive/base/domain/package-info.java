package com.hncboy.beehive.base.domain;
/*
 * bo 业务对象
 * entity 数据库实体类
 * request 前端请求参数
 * query 前端查询参数
 * vo 后端返回给前端的参数
 */