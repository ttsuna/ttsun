package com.hncboy.beehive.base.constant;

/**
 * @author hncboy
 * @date 2023/6/18
 * 授权相关常量
 */
public class AuthConstant {

    /**
     * bearer
     */
    public static final String BEARER = "Bearer ";
}
