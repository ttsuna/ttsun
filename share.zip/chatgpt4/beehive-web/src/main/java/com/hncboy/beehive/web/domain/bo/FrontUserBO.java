package com.hncboy.beehive.web.domain.bo;

import lombok.Data;

/**
 * @author hncboy
 * @date 2023/6/27
 * 前端用户业务参数对象
 */
@Data
public class FrontUserBO {


}
