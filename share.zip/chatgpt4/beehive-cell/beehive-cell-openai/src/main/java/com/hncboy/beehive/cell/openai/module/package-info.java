package com.hncboy.beehive.cell.openai.module;

/*
 * chat 对话
 * key 密钥
 */