package com.hncboy.beehive.cell.core.constant;

/**
 * @author hncboy
 * @date 2023/6/2
 * Cell 常量
 */
public class CellConstant {
}
