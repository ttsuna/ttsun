package com.hncboy.beehive.cell.bing.constant;

/**
 * @author hncboy
 * @date 2023/6/18
 * NewBing 常量
 */
public class NewBingConstant {

    /**
     * 响应成功
     */
    public static final String RESPONSE_SUCCESS = "Success";
}
