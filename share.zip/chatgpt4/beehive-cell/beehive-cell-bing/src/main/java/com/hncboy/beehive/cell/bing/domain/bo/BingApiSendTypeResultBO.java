package com.hncboy.beehive.cell.bing.domain.bo;

import lombok.Data;

/**
 * @author hncboy
 * @date 2023/5/26
 * BingApi 发送消息响应参数
 */
@Data
public class BingApiSendTypeResultBO {

    private Integer type;
}
